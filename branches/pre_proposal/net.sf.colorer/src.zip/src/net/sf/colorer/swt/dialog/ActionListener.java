package net.sf.colorer.swt.dialog;

/**
 * @author irusskih
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public interface ActionListener {
  /**
   * Action, which was taken over dialog
   * @param gd source dialog
   * @param action type of action
   */
  void action(GeneratorDialog gd, int action);
}
